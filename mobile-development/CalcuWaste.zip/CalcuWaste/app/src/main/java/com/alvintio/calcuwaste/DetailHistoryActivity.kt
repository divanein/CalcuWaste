package com.alvintio.calcuwaste

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DetailHistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_history)
    }
}